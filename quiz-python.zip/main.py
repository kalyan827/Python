print('WELCOME TO QUIZ!')
playing=input('Do you want to play? ')
if playing.upper()!='YES':
    quit()
print("OKAY! Let's play")
score=0

A=input('who is the father of Python? ')
if A.lower()=='guido van rossum':
    print('correct')
    score+=1
else:
    print('incorrect')
    
B=input('what HTML stands for? ')
if B.lower()=='hyper text markup language':
    print('correct')
    score+=1
else:
    print('incorrect')
    
C=input('what is package in python? ')
if C.lower()=='collection of different modules':
    print('correct')
    score+=1
else:
    print('incorrect')
    
print('your score '+str(score)+' questions correct')
print('your percentage '+str((score/3)*100)+'%')
    

    
    
